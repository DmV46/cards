import PlacesList from './classes/placesList.js';

const placesList = new PlacesList(document.querySelector('.places-list'), []);

export default placesList;
